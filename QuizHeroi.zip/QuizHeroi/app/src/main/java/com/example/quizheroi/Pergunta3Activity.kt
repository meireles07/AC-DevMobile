package com.example.quizheroi

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class Pergunta3Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pergunta3)

        val btn = findViewById<Button>(R.id.btnFinalizar)
        val rg = findViewById<RadioGroup>(R.id.rgP3)

        btn.setOnClickListener {
            var b = intent.getIntExtra("B", 0)
            var a = intent.getIntExtra("A", 0)
            var c = intent.getIntExtra("C", 0)

            when(rg.checkedRadioButtonId) {
                R.id.rbBatman3 -> b++
                R.id.rbAranha3 -> a++
                R.id.rbCapitao3 -> c++
                else -> return@setOnClickListener
            }

            val intent = Intent(this, ResultadoActivity::class.java)
            intent.putExtra("B", b)
            intent.putExtra("A", a)
            intent.putExtra("C", c)
            startActivity(intent)
        }
    }
}