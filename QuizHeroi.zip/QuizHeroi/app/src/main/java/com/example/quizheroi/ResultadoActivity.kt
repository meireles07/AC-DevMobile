package com.example.quizheroi

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.net.Uri
import android.widget.Button

class ResultadoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        val tvResultado = findViewById<TextView>(R.id.tvResultado)

        val b = intent.getIntExtra("B", 0)
        val a = intent.getIntExtra("A", 0)
        val c = intent.getIntExtra("C", 0)

        val heroi = when {
            b >= a && b >= c -> "Batman 🦇"
            a >= b && a >= c -> "Homem-Aranha 🕷️"
            else -> "Capitão América 🛡️"
        }

        tvResultado.text = "O herói que combina com você é:\n$heroi"

        val btnGithub = findViewById<Button>(R.id.btnGithub)
        btnGithub.setOnClickListener {
            val url = "https://github.com/meireles07/AC-DevMobile"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }
    }
}
