package com.example.quizheroi

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn = findViewById<Button>(R.id.btnProx1)
        val rg = findViewById<RadioGroup>(R.id.rgP1)

        btn.setOnClickListener {
            var b = 0
            var a = 0
            var c = 0

            when(rg.checkedRadioButtonId) {
                R.id.rbBatman -> b++
                R.id.rbAranha -> a++
                R.id.rbCapitao -> c++
                else -> return@setOnClickListener
            }

            val intent = Intent(this, Pergunta2Activity::class.java)
            intent.putExtra("B", b)
            intent.putExtra("A", a)
            intent.putExtra("C", c)
            startActivity(intent)
        }
    }
}